#include "Tienda.h";
int main()
{
	Tienda LaMejor; 

	cout << endl;
	LaMejor.Poblar();
	cout << "\n\t\ Original " << endl; 
	LaMejor.Mostrar(); 
	cout << "\n\n\t\t...ordenado...\t" << endl;
	LaMejor.Ordenar();
	cout << "\n\t\t Ordenado" << endl; 


}