#include "Tienda.h"
#include <iostream>
using namespace std;
#include "string.h"

Tienda::Tienda()
{
	ocupados = 0;
}

void Tienda::Mostrar()
{
	cout << "\nSucursales:" << endl;

		for (int i = 0; i < ocupados; i++)
	{
		    cout << "\t" << sucs[i].numSuc << "\t " << sucs[i].nomGte
			<< "\t" << sucs[i].ventas[0] << "\t" << sucs[i].ventas[1] << endl;

	}
	cout << endl;
}

void Tienda::Ordenar()
{
	bool odenado = false; 
	Sucursal aux; 
	int ite = 0; 

	while (!odenado)
	{
		odenado = true;
		for (int i = 0; i < ocupados - ite - 1; i++)
		{

			if (sucs[i].numSuc > sucs[i + 1].numSuc)
			{
				aux = sucs[i];
				sucs[i] = sucs[i + 1];
				sucs[i + 1] = aux; 
				odenado = false;

			}
		}
		ite++;
	}
}

void Tienda::Poblar()
{

	int numS;
	if (ocupados >= tama�o)
	{
		cout << "\n\t Arreglo lleno, no puedes registrar la sucursal\n" << endl;
		return;

	}

	do
	{
		cout << "\n Num sucursal: ";
		cin >> numS;
		if (numS != 999)
		{
			sucs[ocupados].numSuc = numS;
			cout << "Nombre Gerente: ";
			cin >> sucs[ocupados].nomGte;
			cout << "Ventas mes anterior: ";
			cin >> sucs[ocupados].ventas[0];
			cout << "ventas ultimo mes: ";
			cin >> sucs[ocupados].ventas[1];
			ocupados++;
		}
	
	} while (numS != 999);
}