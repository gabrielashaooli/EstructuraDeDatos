#pragma once
#include <iostream>
using namespace std;
#define tama�o 3

struct Sucursal /*clausula para crear un registro*/
{
	int numSuc;
	string nomGte;
	int ventas[2];
};

class Tienda
{
public:
	Tienda();
	void Mostrar();
	void Ordenar();
	void Poblar();
	
private: 
	Sucursal sucs[tama�o];
	int ocupados; 
};
