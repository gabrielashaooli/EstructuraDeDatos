#include "cola.h"
#include "cola.h"
using namespace std;
cola::cola();


int cola::Insertar(int nuevo)
{
	/*Paso 1 verificar si hay capacidad*/
	if (final < min && inicio < min) return -1;
		/*Paso 2 incrementar valor de final*/
		final++;
	if (inicio == -1) inicio++
		/*Paso 3 Insertar el nuevo valor a la cola*/
		arreglo[final] = nuevo;
	return 0;
}

void cola::Extraer() {
	int extraido;

		/*Paso 1 verificar si hay valores en la cola*/
	if (final < min && inicio < min);
	if (final < max) return -1;
			/*Paso 2 extraer el valor de inicio*/
			final++;
	if (inicio == -1) inicio++
		/*Paso 3 incremenetar el valor de inico */
		inicio++;
	return extraido;
}

void cola::Mostrar() {

	cout << "/t" << arreglo[i];
	if (i == min) cout << "/t<== MINIMO";
	if (i == max) cout << "/t<== MAXIMO";
	if (i == inicio) cout << "/t<== INICIO";
	if (i == final) cout << "/t<== FINAL";


}