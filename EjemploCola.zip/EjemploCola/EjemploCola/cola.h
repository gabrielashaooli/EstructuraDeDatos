#pragma once
class cola
{
public:
cola();
~cola();
int Insertar();
void Mostrar();
void Extraer();

private:
	string* arreglo;
	int min, max, tope;
	int final, inicio;
};

