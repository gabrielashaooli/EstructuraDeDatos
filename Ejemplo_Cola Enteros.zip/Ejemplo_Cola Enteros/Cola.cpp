#include "Cola.h"

Cola::Cola()
{
	min = 0;
	max = TAM - 1;
	inicio = final = -1;
	for (int i = 0; i < TAM; i++) arreglo[i] = 0;
}
Cola::~Cola()
{}
int Cola::Extraer()
{
	int extraido;

	/* Paso 1: Verificar si hay valores en la cola */
	if (final < min && inicio < min) return -1;
	if (inicio > final) return -1;
	/* Paso 2: Extraer el valor de inicio */
	extraido = arreglo[inicio];
	arreglo[inicio] = 0;
	/* Paso 3: Incrementar el valor de inicio */
	inicio++;

	return extraido;
}
int Cola::Insertar(int nuevo)
{
	/* Paso 1: Verificar si hay capacidad */
	if (final == max) return -1;
	/* Paso 2: Incrementar valor de final */
	final++;
	if (inicio == -1)inicio++;
	/* Paso 3: Insertar el nuevo valor a la Cola */
	arreglo[final] = nuevo;

	return 0;
}
void Cola::Mostrar()
{
	cout << "\nCOLA:" << endl;
	for (int i = TAM - 1; i >= 0; i--)
	{
		cout << "\t" << arreglo[i];
		if (i == min) cout << "\t<== M�nimo";
		if (i == max) cout << "\t<== M�ximo";
		if (i == inicio) cout << "\t<== Inicio";
		if (i == final) cout << "\t<== Final";
		cout << endl;
	}
}