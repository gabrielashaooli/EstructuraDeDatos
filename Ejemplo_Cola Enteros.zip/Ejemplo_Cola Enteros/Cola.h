#pragma once
#include <iostream>
#define TAM 6
using namespace std;

class Cola
{
public:
	Cola();
	~Cola();
	int Extraer();
	int Insertar(int);
	void Mostrar();
private:
	int arreglo[TAM];
	int min, max, inicio, final;
};
