#include "Cola.h"

int main()
{
	setlocale(LC_ALL, "");
	Cola Enteros;
	int num, opc, resultado;

	do
	{
		cout << "\n1 Insertar   2 Extraer   3 Mostrar   4 Salir: ";
		cin >> opc;

		switch (opc)
		{
		case 1:
			cout << "\t�Qu� entero quieres insertar?: ";
			cin >> num;
			resultado = Enteros.Insertar(num);
			if (resultado == -1)
				cout << "\n\t**Cola LLENA. NO se insert�" << endl;
			else
				cout << "\n\tOK. Se insert� correctamente" << endl;
			break;
		case 2:
			resultado = Enteros.Extraer();
			if (resultado == -1)
				cout << "\n\t**Cola VAC�A. Nada que extraer" << endl;
			else
				cout << "\n\tSe extrajo el entero: " << resultado << endl;
			break;
		case 3:
			Enteros.Mostrar();
			break;
		default:
			break;
		}

	} while (opc < 4);
}