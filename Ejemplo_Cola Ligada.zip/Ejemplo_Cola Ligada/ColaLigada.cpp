#include "ColaLigada.h"

ColaLigada::ColaLigada()
{
	inicio = final = nodo = NULL;
}
ColaLigada::~ColaLigada()
{}
int ColaLigada::Extraer()
{
	int extraido;

	/* Paso 1: Revisar si existe informaci�n en la Fila */
	if (inicio == NULL)
		return -1;
	/* Paso 2: Iguar nodo a inicio */
	nodo = inicio;
	/* Paso 3: Tomar informaci�n del nodo de inicio */
	extraido = nodo->num;
	/* Paso 4: Apuntar inicio al siguiente nodo */
	inicio = nodo->sig;
	/* Paso 5: Si se extrajo el �ltimo nodo, final debe apuntar a NULL */
	if (inicio == NULL)
		final = NULL;
	/* Paso 6: Liberar el nodo extraido */
	delete nodo;

	return extraido;
}
void ColaLigada::Insertar(int nvo)
{
	/* Paso 1: Crear nodo */
	nodo = new Enteros;
	/* Paso 2: Asignar datos a la parte de informaci�n */
	nodo->num = nvo;
	/* Paso 3: Asignar dir del siguiente nodo a la parte de enlace */
	nodo->sig = NULL;
	/* Paso 4: Si es primer nodo, apuntar inicio a este nuevo nodo */
	if (inicio == NULL)
		inicio = nodo;
	/* Paso 5: Si NO es el primer nodo, actualizar el enlace del nodo final actual */
	if (final != NULL)
		final->sig = nodo;
	/* Paso 6: Apuntar final al nuevo nodo */
	final = nodo;
}
void ColaLigada::Mostrar()
{
	nodo = inicio;
	cout << "\nFILA de ENTEROS:" << endl;
	if (nodo == NULL)
	{
		cout << "\n\tLa Fila est� VAC�A" << endl;
		return;
	}
	while (nodo != NULL)
	{
		cout << "\t" << nodo->num;
		if (nodo == inicio) cout << "\t<== Inicio";
		if (nodo == final) cout << "\t<== Final";
		cout << endl;

		nodo = nodo->sig;
	}
}
