#include "ColaLigada.h"

int main()
{
	setlocale(LC_ALL, "");
	ColaLigada filaEnteros;
	int nuevo, opc, extraido;

	do
	{
		cout << "\n1 Insertar   2 Extraer   3 Mostrar   4 Salir: ";
		cin >> opc;
		switch (opc)
		{
		case 1:
			cout << "\tEntero a insertar: ";
			cin >> nuevo;
			filaEnteros.Insertar(nuevo);
			cout << "\n\tOK. Se insert�" << endl;
			break;
		case 2:
			extraido = filaEnteros.Extraer();
			if (extraido == -1)
				cout << "\n\t**Cola VAC�A. NO se extrajo nada" << endl;
			else
				cout << "\n\tSe extrajo el entero: " << extraido << endl;
			break;
		case 3:
			filaEnteros.Mostrar();
			break;
		default:
			break;
		}
	} while (opc < 4);
}