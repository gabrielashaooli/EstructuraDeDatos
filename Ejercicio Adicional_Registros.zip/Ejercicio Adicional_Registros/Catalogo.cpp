#include "Catalogo.h"

Catalogo::Catalogo()
{
	setlocale(LC_ALL, "");
}
void Catalogo::Registrar()
{
	cout << "\nNombre: ";
	getline(cin, catalog[ocupados].nombre);
	cout << "Calle: ";
	cin >> catalog[ocupados].ubica.calle;
	cout << "N�mero: ";
	cin >> catalog[ocupados].ubica.num;
	cout << "Cod.Postal: ";
	cin >> catalog[ocupados].ubica.cPostal;

	ocupados++;
}
Empleado Catalogo::Buscar(string nom)
{
	Empleado encontrado;

	for (int i = 0; i < ocupados; i++)
	{
		if (nom == catalog[i].nombre)
			return catalog[i];
	}

	encontrado.nombre = "";
	return encontrado;
}
void Catalogo::Mostrar()
{
	cout << "\nCATALOGO:" << endl << endl;
	for (int j = 0; j < ocupados; j++)
		cout << catalog[j].nombre << "\t" << catalog[j].ubica.calle << "\t" << catalog[j].ubica.num
		<< "\t" << catalog[j].ubica.cPostal << endl;
	cout << "\n\t== FIN de Cat�logo ==" << endl;
}