#pragma once
#include <iostream>
#include <string>
#define TAM 5
using namespace std;

struct Domicilio
{
	string calle;
	int num;
	string cPostal;
};

struct Empleado
{
	string nombre;
	Domicilio ubica;
};

class Catalogo
{
public:
	Catalogo();
	void Registrar();
	Empleado Buscar(string);
	void Mostrar();
private:
	Empleado catalog[TAM];
	int ocupados = 0;
};

