#include "Catalogo.h"

int main()
{
	Catalogo tienda1;
	char resp='s';
	string buscado;
	Empleado encontrado;

	tienda1.Mostrar();

	while (resp == 's' || resp == 'S')
	{
		tienda1.Registrar();
		cout << "\n�Registrar otro empleado? <s/n>: ";
		cin >> resp;

		cin.ignore();
	}
	tienda1.Mostrar();

	resp = 's';
	while (resp == 's' || resp == 'S')
	{
		cout << "\n�Qu� empleado buscar�s?: ";
		getline(cin, buscado);
		encontrado = tienda1.Buscar(buscado);
		if (encontrado.nombre == "")
			cout << "\n\t**NO existe el empleado buscado" << endl;
		else
			cout << "\n" << encontrado.nombre << "\t" << encontrado.ubica.calle << "\t" << encontrado.ubica.num
			<< "\t" << encontrado.ubica.cPostal << endl;
		cout << "\n�Buscar otro empleado? <s/n>: ";
		cin >> resp;
		if (resp == 's')
			cin.ignore();
	}
	cout << "\n" << endl;
}