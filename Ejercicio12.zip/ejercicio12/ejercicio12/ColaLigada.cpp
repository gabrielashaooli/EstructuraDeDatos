#include "ColaLigada.h"

ColaLigada::ColaLigada() {
	inicio = final = nodo = NULL; 
}
ColaLigada :: ~ColaLigada(){
}

string ColaLigada::Extraer(){

	string extraido;
	if (inicio == NULL)
		return "";
	nodo = inicio; 
	extraido = nodo->dato; 
	inicio = nodo->sig;
	if (inicio == NULL)
		final = NULL; 
	delete nodo; 
	return extraido; 
}
void ColaLigada:: Insertar(string nvo) {

	nodo = new Frase; 
	nodo->dato = nvo;
	nodo->sig = NULL;
	if (inicio == NULL)
		inicio = nodo; 
	if (final != NULL)
		final->sig = nodo; 
		final = nodo; 
	}

void ColaLigada::Mostrar() {
	cout << "\nFRASES" << endl; 
	if (inicio = NULL);
	{
		cout << "\n\t COLA VACIA" << endl;
		return; 
	}
	nodo = inicio; 

	while (nodo != NULL)
	{
		cout << nodo->dato;

		cout << nodo-> dato;
		if (nodo == inicio) cout << "/t<== INICIO";
		if (nodo == final) cout << "/t<== FINAL";
	cout << endl;
	nodo = nodo->sig; 
		}

	}
