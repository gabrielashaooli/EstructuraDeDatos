#pragma once
#include "ColaLigada.h"
#include<iostream>
using namespace std;

	struct Frase
	{
		string dato;
		Frase* sig;
	};

	class ColaLigada
	{
	public:
		ColaLigada();
		~ColaLigada();
		string Extraer();
		void Insertar(string);
		void Mostrar();

	private:
		Frase* inicio, * final, * nodo;
	};

