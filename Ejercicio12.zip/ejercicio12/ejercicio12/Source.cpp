/*Construye una aplicacion que permite Insertar y Extraer frases en una Cola ligada, mediante la implementaciooon dinamica del tda cola. 
Cada frase son varias plabaras separadas por espacios tambien 
debe ofrecer la opcion de mostrar la fila completo y los parametros de la fila*/

#include "ColaLigada.h"

using namespace std;

void main() {
	int op, tam;
	string entrar, salir, pal;

	ColaLigada palabras;

	do
	{
		cout << "\n\t 1.INSERTAR 2. EXTRAER 3.MOSTRAR 4.SALIR ";
		cin >> op;

		switch (op)
		{
		case 1:
			cout << "\t PALABRA: ";
			cin >> entrar;
			palabras.Insertar(entrar);

			if (pal == "")
				cout << "\t SE HA INSERTADO: " << endl;
			else
				cout << "\n\t\ NO SE INSERTO" << endl;
			break;

		case 2:
			salir = palabras.Extraer();
			if (salir == "")
				cout << "\t NADA QUE EXTRAER, COLA VACIA: \t" << salir << endl;
			else
				cout << "\n\t SE EXTRAJO LA PALABRA: \n" << salir << endl;
			break;

		case 3:
			palabras.Mostrar();
			break;
		default:
			cout << "Opcion invalida" << endl;
			break;
		}
	} while (op < 4);
}