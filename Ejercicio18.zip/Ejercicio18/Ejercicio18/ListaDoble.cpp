#include "ListaDoble.h"

ListaDoble::ListaDoble()
{
	cabecera = final = NULL;
}

ListaDoble::~ListaDoble() {

}

void ListaDoble::InsertarInicio(string nueva)
{
	nodo = new Palabras;
	nodo->dato = nueva;	
	nodo->siguiente = cabecera;
	nodo->anterior = NULL;
	if (cabecera != NULL)
		cabecera->anterior = nodo;
	else
		final = nodo;
	cabecera = nodo;
}

bool ListaDoble::InsertarIntermedio(string nueva, string despues)
{
	bool encontrada = false;
	Palabras* anterior;
	if (!cabecera)
		return false;
	anterior = cabecera;
	do
	{
		if (anterior->dato == despues)	
		{
			encontrada = true;
			break;
		}

		anterior = anterior->siguiente;

	} while (anterior != NULL);

	if (encontrada == false)
		return false;

	if (anterior == final)
	{
		InsertarFinal(nueva);
		return true;
	}
	nodo = new Palabras;		
	nodo->dato = nueva;
	nodo->siguiente = anterior->siguiente;
	nodo->anterior = anterior;		
	anterior->siguiente = nodo;
	nodo->siguiente->anterior = nodo;

	return true;
}

void ListaDoble::InsertarFinal(string nueva)
{
	if (cabecera == NULL)
	{
		InsertarInicio(nueva);
		return;
	}
	nodo = new Palabras;
	nodo->dato = nueva;
	nodo->siguiente = NULL;
	nodo->anterior = final;
	final->siguiente = nodo;
	final = nodo;
}

string ListaDoble::ExtraerInicio()
{
	string extraida;

	if (!cabecera)
		return "";

	nodo = cabecera;
	extraida = nodo->dato;

	cabecera = nodo->siguiente;	
	if (nodo == final)	
		final = NULL;
	else
		nodo->siguiente->anterior = NULL;

	delete nodo;		

	return extraida;
}

string ListaDoble::ExtraerIntermedio(string aExtraer)
{
	string extraida;
	bool encontrada = false;

	if (!cabecera)
		return "";

	nodo = cabecera;
	do				
	{
		if (nodo->dato == aExtraer)
		{
			encontrada = true;
			break;
		}
		nodo = nodo->siguiente;
	} while (nodo != NULL);
	if (!encontrada)	
		return "";
	if (nodo == cabecera)	
	{
		extraida = ExtraerInicio();
		return extraida;
	}
	if (nodo == final)	
	{
		extraida = ExtraerFinal();
		return extraida;
	}
	extraida = nodo->dato;
	nodo->anterior->siguiente = nodo->siguiente;
	nodo->siguiente->anterior = nodo->anterior;
	delete nodo;					

	return extraida;
}


string ListaDoble::ExtraerFinal()
{
	string extraida;

	if (cabecera == NULL)
		return "";
	nodo = final;
	extraida = nodo->dato;

	final = nodo->anterior;
	if (nodo == cabecera)
		cabecera = NULL;
	else
		final->siguiente = NULL;
	delete nodo;

	return extraida;
}

void ListaDoble::MostrarInicio_Final()
{
	cout << "\nLista de Palabras:" << endl;
	cout << "\n\t incio de la lista" << endl;
	if (!cabecera)
	{
		cout << "\n\tlista vacia, no se encontro nada" << endl;
		return;
	}
	nodo = cabecera;
	do
	{
		cout << "\t" << nodo->dato;
		if (nodo == cabecera) cout << "\t<== Cabecera";
		if (nodo == final) cout << "\t<== Final";
		cout << endl;

		nodo = nodo->siguiente;

	} while (nodo != NULL);
	cout << "\n\t Fin de la lista" << endl;
}
void ListaDoble::MostrarFinal_Inicio()
{
	cout << "\nLista de Palabras:" << endl;
	if (!cabecera)
	{
		cout << "\n\tLista vacia, no se encontro nada" << endl;
		return;
	}

	cout << "\n\tFin de la lista" << endl;
	nodo = final;
	do
	{
		cout << "\t" << nodo->dato;
		if (nodo == cabecera) cout << "\t<== Cabecera";
		if (nodo == final) cout << "\t<== Final";
		cout << endl;

		nodo = nodo->anterior;

	} while (nodo != NULL);
	cout << "\n\t Incio de la lista" << endl;
}