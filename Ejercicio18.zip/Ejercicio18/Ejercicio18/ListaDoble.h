#pragma once
#include <iostream>
using namespace std;

struct Palabras
{
	Palabras* anterior;
	string dato;
	Palabras* siguiente;
};

class ListaDoble
{
public:
	ListaDoble();
	~ListaDoble();
	void InsertarInicio(string);
	bool InsertarIntermedio(string, string);
	void InsertarFinal(string);
	string ExtraerInicio();
	string ExtraerIntermedio(string);
	string ExtraerFinal();
	void MostrarInicio_Final();
	void MostrarFinal_Inicio();
private:
	Palabras* cabecera, * final, * nodo;
};