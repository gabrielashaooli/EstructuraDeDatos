#include "ListaDoble.h"

int main()
{
	setlocale(LC_ALL, "");

	ListaDoble MiLista;
	int opc;
	string nueva, despues, extraida, extraer;
	bool resultado;

	do
	{
		cout << "\n 1 INSERTAR INICIO";
		cout << "\n 2 INSERTAR INTERMEDIO";
		cout << "\n 3 INSERTAR FINAL";
		cout << "\n 4 EXTRAER INICIO ";
		cout << "\n 5 EXTRAER INTERMEDIO";
		cout << "\n 6 EXTRAER FINAL";
		cout << "\n 7 MOSTRAR INICIO Y FINAL";
		cout << "\n 8 MOSTRAR FINAL Y INICIO";
		cout << "\n 9 SALIR: ";
		cout << "\n Inserte una opcion: ";
		cin >> opc;

		if (opc < 4)
		{
			cout << "\n\t�Qu� palabra le gustatia insertar?: ";
			cin >> nueva;
		}

		switch (opc)
		{
		case 1:
			MiLista.InsertarInicio(nueva);
			cout << "\tSe ha insertado la palabra al incio" << endl;
			break;
		case 2:
			MiLista.InsertarFinal(nueva);
			cout << "\tSe ha insertado la palabra al final" << endl;
			break;
		case 3:
			cout << "\tDesp�es de qu� palabra quieres insertar: ";
			cin >> despues;
			resultado = MiLista.InsertarIntermedio(nueva, despues);
			if (resultado == true)
				cout << "\tSe inserto despues de la palabra" << despues << endl;
			else
				cout << "\tEsa palabra no existe '" << despues << "'. no se pudo insertar" << endl;
			break;
		case 4:
			extraida = MiLista.ExtraerInicio();
			if (extraida == "")
				cout << "\n\tLista vacia, no se pudo extraer nada" << endl;
			else
				cout << "\n\tSe extrajo desde el incio la palabra: " << extraida << endl;
			break;
		case 5:
			extraida = MiLista.ExtraerFinal();
			if (extraida == "")
				cout << "\n\tLista vacia. No se pudo extraer nada" << endl;
			else
				cout << "\n\tSe extrajo desde el final la palabra: " << extraida << endl;
			break;
		case 6:
			cout << "\t�Qu� palabra quieres extraer?: ";
			cin >> extraer;
			extraida = MiLista.ExtraerIntermedio(extraer);
			if (extraida == "")
				cout << "\n\tNo existe la palabra '" << aExtraer << "'. no se pudo exttraer nada" << endl;
			else
				cout << "\n\tSe extrajo desde el itermedio la palabra: " << extraida << endl;
			break;
		case 7:
			MiLista.MostrarInicio_Final();
			break;
		case 8:
			MiLista.MostrarFinal_Inicio();
			break;
		default:
			break;
		}
	} while (opc < 9);
}


