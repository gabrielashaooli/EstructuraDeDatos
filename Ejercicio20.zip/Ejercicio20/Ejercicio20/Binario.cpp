#include "Binario.h"
Binario::Binario() {
	raiz = nodo = NULL;
}
void Binario::Crear(int nuevo) {
	nodo = new Num;
	nodo->numero = nuevo;
	nodo->izq = NULL;
	nodo->der = NULL;
}
Num* Binario::getRaiz() {
	return raiz;
}
void Binario::Insertar(Num* nuevo) {
	if (raiz == NULL) {
		raiz = nodo;
		cout << "Raiz creada." << endl;
		return;
	}
	if (nodo->numero < nuevo->numero) {
		if (nuevo->izq == NULL) {
			nuevo->izq = nodo;
			cout << "Se insert� a la izquierda de " << nuevo->numero << endl;
			return;
		}
		else {
			Insertar(nuevo->izq);
			return;
		}
	}
	if (nodo->numero > nuevo->numero) {
		if (nuevo->der == NULL) {
			nuevo->der = nodo;
			cout << "Se insert� a la derecha de " << nuevo->numero << endl;
			return;
		}
		else {
			Insertar(nuevo->der);
			return;
		}
	}
	cout << "Este n�mero ya existe, no se insert� nada." << endl;
}
void Binario::RecorrerInOrden(Num* nuevo) {
	if (raiz == NULL) {
		cout << "El �rbol se encuentra vac�o..." << endl;
		return;
	}
	if (nuevo->izq != NULL) RecorrerInOrden(nuevo->izq);
	cout << nuevo->numero << endl;;
	if (nuevo->der != NULL) RecorrerInOrden(nuevo->der);
}
void Binario::RecorrerPreOrden(Num* nuevo) {
	if (raiz == NULL) {
		cout << "El �rbol se encuentra vac�o..." << endl;
		return;
	}
	cout << nuevo->numero << endl;;
	if (nuevo->izq != NULL) RecorrerPreOrden(nuevo->izq);
	if (nuevo->der != NULL) RecorrerPreOrden(nuevo->der);
}
void Binario::RecorrerPosOrden(Num* nuevo) {
	if (raiz == NULL) {
		cout << "El �rbol se encuentra vac�o..." << endl;
		return;
	}
	if (nuevo->izq != NULL) RecorrerPosOrden(nuevo->izq);
	if (nuevo->der != NULL) RecorrerPosOrden(nuevo->der);
	cout << nuevo->numero << endl;;
}