#pragma once
#include <iostream>
using namespace std;
struct Num {
	Num* izq;
	int numero;
	Num* der;
};
class Binario
{
public:
	Binario();
	void Crear(int);
	void Insertar(Num*);
	Num* getRaiz();
	void RecorrerInOrden(Num*);
	void RecorrerPreOrden(Num*);
	void RecorrerPosOrden(Num*);
private:
	Num* raiz, * nodo;
};

