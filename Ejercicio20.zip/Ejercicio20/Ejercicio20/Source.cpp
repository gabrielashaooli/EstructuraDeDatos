#include "Binario.h"
enum Menu {
    Insertar = 1,
    RecorrerIn,
    RecorrerPre,
    RecorrerPos,
    Salir
};
void Menu() {
    cout << "\n\n Men�\n" << endl;
    cout << " 1) Insertar" << endl;
    cout << " 2) Recorrer en in-orden" << endl;
    cout << " 3) Recorrer en pre-orden" << endl;
    cout << " 4) Recorrer en pos-orden" << endl;
    cout << " 5) Salir" << endl;
}
int main()
{
    setlocale(LC_ALL, "");
    int entra;  int opcion;
    Num* inicio;
    Arbol ABB;
    bool correrPrograma = true;
    while (correrPrograma) {
        Menu();
        cout << "\nDigita la opci�n que quieres realizar: ";
        cin >> opcion;
        switch (opcion) {
        case Insertar:
            cout << "\n�Qu� n�mero deseas insertar? ";
            cin >> entra;
            ABB.Crear(entra);
            inicio = ABB.getRaiz();
            ABB.Insertar(inicio);
            break;
        case RecorrerIn:
            inicio = ABB.getRaiz();
            ABB.RecorrerInOrden(inicio);
            break;
        case RecorrerPre:
            inicio = ABB.getRaiz();
            ABB.RecorrerPreOrden(inicio);
            break;
        case RecorrerPos:
            inicio = ABB.getRaiz();
            ABB.RecorrerPosOrden(inicio);
            break;
        case Salir:
            correrPrograma = false;
            break;
        }
    }
}