#pragma once
#include <iostream>
using namespace std;

class PilaPantallas
{
public:
	PilaPantallas(int);
	int Insertar(string);
	string Extraer();
	string Consultar();
	void Mostrar();
private:
	string* arreglo;
	int minimo, maximo, tope;
	int tamano;
};

