#include "PilaPantallas.h"

int main()
{
	setlocale(LC_ALL, "");
	int cuantas;

	cout << "\t�Cu�ntas caben en la pila?: ";
	cin >> cuantas;

	PilaPantallas almacen1(cuantas);
	int opc, resultado;
	string modelo = "";

	do
	{
		cout << "\n1 Insertar   2 Extraer   3 Consultar   4 Mostrar   5 Salir: ";
		cin >> opc;
		switch (opc)
		{
		case 1:
			cout << "\t�Qu� modelo insertas?: ";
			cin >> modelo;
			resultado = almacen1.Insertar(modelo);
			if (resultado == 0)
				cout << "\tOK. Se insert� " << modelo << endl;
			break;
		case 2:
			modelo = almacen1.Extraer();
			if (modelo != "")
				cout << "\tOK. Se extrajo " << modelo << endl;
			break;
		case 3:
			modelo = almacen1.Consultar();
			if (modelo != "")
				cout << "\tEl valor en tope es: " << modelo << endl;
			break;
		case 4:
			almacen1.Mostrar();
			break;
		default:
			break;
		}
	} while (opc < 5);
}