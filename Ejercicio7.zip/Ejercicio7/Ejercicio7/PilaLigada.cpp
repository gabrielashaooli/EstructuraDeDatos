#include "PilaLigada.h"
PilaLigada::PilaLigada(){
	setlocale(LC_ALL, "");
	tope = NULL;
}

void PilaLigada ::Insertar (Empleado nvoEmp) {
	nuevo = new Empleado;
	*nuevo = nvoEmp;

	nuevo->anterior = tope;
	tope = nuevo;
}

Empleado PilaLigada::Extraer() {
	Empleado* extraido;
	Empleado resultado;
	if (tope == NULL)
	{
		resultado = Limpiar(resultado);
		return resultado;
	}
	extraido = tope;
	tope = extraido->anterior;
	resultado = *extraido;
	delete extraido;

	return resultado;
	}

void PilaLigada::Mostrar() {

	cout << "\nContratados: " << endl;
	if (tope == NULL)
	{
		cout << "\n\T no hay empleados contratados" << endl;
	return;
}
nuevo = tope;
while (nuevo != NULL)
{
	cout << "t" << nuevo->cve << "\t" << nuevo->nom
		<< "t$" << nuevo->sdo;
	if (nuevo == tope)
		cout << "\t" << "<- tope"; 
	cout << endl; 
	nuevo = nuevo->anterior;
}

cout << "n\t == Final == " << endl;
}

void PilaLigada::Limpiar(Empleado nodo) {
	nodo.cve = 0;
	nodo.nom = "";
	nodo.sdo = 0;

}