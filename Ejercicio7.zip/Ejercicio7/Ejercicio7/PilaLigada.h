#pragma once
#include<iostream>
using namespace std;

struct Empleado
{
	int cve;
	string nom;
	int sdo;
	Empleado* anterior;

};
class PilaLigada
{
public:
	PilaLigada();
	void Insertar(Empleado);
	Empleado Extraer();
	void Mostrar();

	private:
		void Limpiar(Empleado);
		Empleado* tope, * nuevo;

};

