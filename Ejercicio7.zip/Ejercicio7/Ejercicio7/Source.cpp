#include"PilaLigada.h"
#include "PilaLigada.cpp"
int main() {

	int opc = 0, entra;
	Empleado resultado, contratado;
	PilaLigada empleados; 

	do {
		cout << "\n1.Contratar	2. Desocupar	3.Mostrar	4.Salir\n\tSeleccione la opci�n: ";
		cin >> opc;
		switch (opc)
		{
		case 1:
			cout << "\t Clave: ";
			cin >> contratado.cve;
			cout << "\t Nombre: ";
			cin >> contratado.nom;
			cout << "\t Sueldo: ";
			cin >> contratado.sdo;
			empleados.Insertar(contratado);
			cout << "\n\t\ CONTRATADO" << endl;
			break;

		case 2:
			resultado = empleados.Extraer();
			if (resultado.cve == 0)
				cout << "\tNO HAY EMPLEADOS: \t" << resultado << endl << endl;
			else
			{
				cout << "\n\t se desocupo el empleado: \n" << resultado << resultado
					<< "\t" << resultado.nom << "\t$" << resultado;

			}
			break;

		case 3:
			empleados.Mostrar();
			break;
		default:
			cout << "Opcion invalida" << endl;
			break;
		}
	} while (opc != 4);
}