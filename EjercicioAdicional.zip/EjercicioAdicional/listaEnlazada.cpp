#include "listaEnlazada.h"

listaEnlazada::listaEnlazada(){
    cabecera = ultimo = nodo = NULL;
}

void listaEnlazada::ordenador(int n){
    numero* nodoAnter;
	if (!cabecera) { // Si no hay cabecera
		InsertarInicio(n); // Insertar al inicio
		return; // Terminar la funcion
	}
	nodo = cabecera; // Asignar el nodo como cabecera
	while (nodo != NULL) { // Mientras nodo no sea NULL
		if (nodo->num > n && nodo == cabecera) { // Si el dato es mayor al nuevo y el nodo anterior es la cabecera
			InsertarInicio(n); // Insertar al inicio
			return; // Terminar la funcion
		}
		else if (nodo->sig == NULL) { // Si el siguiente nodo es NULL
			InsertarFinal(n); // Insertar al final
			return; // Terminar la funcion
		}
		else if ((nodo->sig->num > n && nodo->num < n) || nodo->num == n) {
			InsertarInter(n, nodo->num); // Insertar en el nodo anterior
			return; // Terminar la funcion
		}
		nodo = nodo->sig;
    }
}

void listaEnlazada::mostrar(){
    nodo = cabecera;
    while(nodo != NULL){
        cout << nodo->num << " ";
        nodo = nodo->sig;
    }
    cout << endl;
}

void listaEnlazada::InsertarInicio(int n){
	nodo = new numero;
	nodo->num = n;
	nodo->sig = cabecera;
	cabecera = nodo;
	if (ultimo == NULL)
		ultimo = nodo;
}

void listaEnlazada::InsertarFinal(int n) {
	if (!cabecera) {
		InsertarInicio(n);
		return;
	}
	nodo = new numero;
	nodo->num = n;
	nodo->sig = NULL;
	ultimo->sig = nodo;
	ultimo = nodo;
}

void listaEnlazada::InsertarInter(int nuevo, int anterior) { //Aqio esta el error
	numero* nodoAnter;
	if (!cabecera) {
		cout << "\n*Lista VACIA, se insertara al inicio" << endl;
		InsertarInicio(nuevo);
		return;
	}
	nodoAnter = cabecera;
	cout << "Cabecera: " << cabecera->num << endl;
	while (nodoAnter != NULL) {
		if (nodoAnter->num == anterior) {
			nodo = new numero;
			nodo->num = nuevo;
			nodo->sig = nodoAnter->sig;
			nodoAnter->sig = nodo;
			return;
		}
		nodoAnter = nodoAnter->sig;
	}
	cout << "*No se encontro el dato anterior " << anterior << " se insertar� al final" << endl;
	InsertarFinal(nuevo);
}

int listaEnlazada::Extraer(){
	int extraido;
	if (!cabecera){
		return -1;
    }
	nodo = cabecera;
	extraido = nodo->num;
	cabecera = nodo->sig;
	delete nodo;
	return extraido;
}