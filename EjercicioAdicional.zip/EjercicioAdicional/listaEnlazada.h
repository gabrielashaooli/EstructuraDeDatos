#include <iostream>

using namespace std;

struct numero{
    int num;
    numero *sig;
};

class listaEnlazada{
    public:
        listaEnlazada();
        void ordenador(int);
        void InsertarInicio(int);
        void InsertarFinal(int);
        void InsertarInter(int, int);
        void mostrar();
        int Extraer();
    private:
        numero* cabecera, *ultimo, *nodo;  
};