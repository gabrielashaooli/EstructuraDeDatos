#include "listaEnlazada.h"

int main(){
    int opc, num, anter, numA , numB ;
    listaEnlazada listaA;
    listaEnlazada listaB;
    listaEnlazada listaC;
    do{
        cout << "1. Insertar en la lista A" << endl;
        cout << "2. Insertar en la lista B" << endl;
        cout << "3. Mostrar lista A" << endl;
        cout << "4. Mostrar lista B" << endl;
        cout << "5. Combinar" << endl;
        cout << "6. Salir" << endl;
        cout << "Opcion: ";
        cin >> opc;
        switch(opc){
            case 1:
                cout << "Numero: ";
                cin >> num;
                listaA.ordenador(num);
                break;
            case 2:
                cout << "Numero: ";
                cin >> num;
                listaB.ordenador(num);
                break;
            case 3:
                listaA.mostrar();
                break;
            case 4:
                listaB.mostrar();
                break;
            case 5:
                do{
                    numA = listaA.Extraer();
                    numB = listaB.Extraer();
                    if(numA != -1){
                        listaC.ordenador(numA);
                    }
                    if(numB != -1){
                        listaC.ordenador(numB);
                    }
                }while(numA != -1 && numB != -1);
                listaC.mostrar();
                break;
            case 6:
                cout << "Adios" << endl;
                break;
            default:
                cout << "Opcion no valida" << endl;
                break;
        }
    }while(opc != 6);
}