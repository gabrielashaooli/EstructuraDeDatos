#include "arreglo.h"
using namespace std;

int main() {
	setlocale(LC_ALL, "");
	arreglo CrearMenu;
	CrearMenu.menu();
}

