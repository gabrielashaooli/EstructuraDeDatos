#include "arreglo.h"
#define TAM 5


void arreglo::sumar() {
    for (int i = 0; i < 5; i++) {
        arrRes[i] = arr1[i] + arr2[i];
    }
    system("Pause");
}

void arreglo::menu() {
    cout << "Arreglos a sumar: " << endl;
    mostrar();
    cout << "\nSumando arreglos" << endl;
    sumar();
    cout << "\nMostrando arreglos y arreglo resultado: " << endl;
    mostrar();
    cout << "\nMostrando arreglo ordenado: " << endl;
    ordenacion();
    mostrar();
}

void arreglo::ordenacion() {
    float temp = 0;
    for (int i = 1; i < TAM; i++) {
        for (int j = 0; j < TAM - 1; j++) {
            if (arrRes[j] > arrRes[j + 1]) {
                temp = arrRes[j];
                arrRes[j] = arrRes[j + 1];
                arrRes[j + 1] = temp;
            }
        }
    }
    cout << endl;
    system("Pause");
}

void arreglo::mostrar() {
    cout << "Array 1: " << endl;
    for (int i = 0; i < 5; i++) {
        cout << arr1[i] << " ";
    }
    cout << endl << "Array 2: " << endl;
    for (int i = 0; i < 5; i++) {
        cout << arr2[i] << " ";
    }
    cout << endl << "Array resultado: " << endl;
    for (int i = 0; i < 5; i++) {
        cout << arrRes[i] << " ";
    }
    cout << endl;
    system("Pause");
}
