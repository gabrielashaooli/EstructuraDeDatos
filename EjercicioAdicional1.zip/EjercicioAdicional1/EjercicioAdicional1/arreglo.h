#pragma once
using namespace std;
#include <iostream>
#include <string>

class arreglo
{
public:
	int opc = 0;
	float arr1[5]{ 2,4,6,8,10 };
	float arr2[5]{ 5,7,3,14,9 };
	float arrRes[5]{ 0,0,0,0,0 };
	void sumar();
	void mostrar();
	void ordenacion();
	void menu();
};

