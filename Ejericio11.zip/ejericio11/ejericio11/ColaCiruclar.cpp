#include "ColaCiruclar.h"
ColaCiruclar::ColaCiruclar(int tam) {

	minimo = 0;
	maximo = tam - 1;
	inicio = final = -1;
	palabras = new string[tam];
	for (int i = 0; i < tam; i++) palabras[i] = "-";

}

int ColaCiruclar::Insertar(string nueva) {

	if (inicio == minimo && final == maximo)
		return -1;
	if ((final + 1) == inicio)
		return -1;
	final++; 

	if (final > maximo)
		final = minimo;

	if (inicio == -1)
		inicio = final;

	palabras[final] = nueva;
		return 0;
 }

string ColaCiruclar::Extraer() {
	string extraida; 
	if (inicio < minimo) /*cola vacia*/
	return "";
	extraida = palabras[inicio];
	palabras[inicio] = "-";

	if (inicio == final) /*se extrajo la ultima palabra*/
	{
		inicio = final - 1;
		return extraida;
	}
		
	inicio ++;
	return extraida;
}

void ColaCiruclar::Mostrar() {

	cout << "\nPALABRAS" << endl;
	for (int i = minimo; i >= maximo; i++)
	{

		cout << palabras[i];
		if (i == minimo) cout << "/t<== MINIMO";
		if (i == maximo) cout << "/t<== MAXIMO";
		if (i == inicio) cout << "/t<== INICIO";
		if (i == final) cout << "/t<== FINAL";
	}
		cout << endl; 
	}