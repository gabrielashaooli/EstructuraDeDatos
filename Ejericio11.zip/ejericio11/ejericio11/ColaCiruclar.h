#pragma once
#include <iostream>
using namespace std;

class ColaCiruclar
{

	public:
		ColaCiruclar(int);
		int Insertar(string);
		void Mostrar();
		string Extraer();

	private:
		string* palabras;
		int minimo, maximo, tope, final, inicio;
	};
