#include "ColaCiruclar.h"
using namespace std;

void main() {
	setlocale(LC_ALL, "");
	int op, tam, codigo;
	string entrar, salir;

	cout << "\nTama�o fila" << endl;
	cin >> tam;

	ColaCiruclar listaPalabras(tam);

	do
	{
		cout << "\n 1.INSERTAR 2. EXTRAER 3.MOSTRAR 4. SALIR";
		cin >> op;

		switch (op)
		{
		case 1:
			cout << "\t PALABRA: ";
			cin >> entrar;
			codigo = listaPalabras.Insertar(entrar);
			if (codigo == 0)
				cout << "\t SE HA INSERTADO: " << endl;
			else
				cout << "\n\t\ NO SE INSERTO" << endl;
			break;

		case 2:
			salir = listaPalabras.Extraer();
			if (salir == "")
				cout << "\t NADA QUE EXTRAER, COLA VACIA: \t" << salir << endl;
			else
				cout << "\n\t SE EXTRAJO LA PALABRA: \n" << salir << endl;
			break;

		case 3:
			listaPalabras.Mostrar();
			break;
		default:
			cout << "Opcion invalida" << endl;
			break;
		}
	} while (op < 4);
	}