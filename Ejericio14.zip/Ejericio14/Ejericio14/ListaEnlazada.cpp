#include "ListaEnlazada.h"
ListaEnlazada::ListaEnlazada() {
	cabecera = final = nodo = NULL;
}

void ListaEnlazada::InsertarInicio(string nueva) {
	nodo = new Palabra;
	nodo-> dato = nueva;
	nodo->sig = cabecera;
	cabecera = nodo;

	if (final == NULL)
		final = nodo;
}

void ListaEnlazada::InsertarFinal(string nueva) {
	if (!cabecera)
	{
		InsertarInicio(nueva);
			return;
	}
	nodo = new Palabra; 
	nodo -> dato = nueva; 
	nodo -> sig = NULL;
	final -> sig = nodo; 
	final = nodo;
}
void ListaEnlazada::InsertarInter(string nueva, string anterior) {
	Palabra* nodoAnter; 

	if (!cabecera)
	{
		cout << "Lista Vacia. Se inserta al inicio" << endl;
		InsertarInicio(nueva);
			return;
	}

	nodoAnter = cabecera;
	while (nodoAnter)
	{
		if (nodoAnter->dato == anterior)
		{
			nodo = new Palabra; 
			nodo->dato = nueva; 
			nodo->sig = nodoAnter->sig;
			nodoAnter->sig = nodo; 
			if (nodoAnter == final)
				final = nodo; 
			return;
		}
	}
}
	void ListaEnlazada::Mostrar() {
		cout << "\nFRASES" << endl;
		if (inicio = NULL);
		{
			cout << "\n\t COLA VACIA" << endl;
			return;
		}
		nodo = inicio;

		while (nodo != NULL)
		{
			cout << nodo->dato;

			cout << nodo->dato;
			if (nodo == inicio) cout << "/t<== INICIO";
			if (nodo == inicio) cout << "/t<== INTERMEDIO";
			if (nodo == final) cout << "/t<== FINAL";

			cout << endl;
			nodo = nodo->sig;
		}

}
