#pragma once
#include <iostream>
#include <string>
using namespace std;

	struct Palabra
	{
		string dato;
		Palabra* sig;
	};

	class ListaEnlazada
	{
	public:
		ListaEnlazada();
		void InsertarInicio(string);
		void InsertarFinal(string);
		void InsertarInter(string, string);
		void Mostrar();

	private:
		Palabra* inicio, * final, * cabecera, * nodo;
	};

