/*Construtye una aplicacion que implemente la opereacion Insertar en una lista enlazada de palabras
Debe exisitir la posiblidad de insertar el principio al final o intermedio- Tambien se pide la opcion mostrar lista completa*/

#include "ListaEnlazada.h"

using namespace std;

void main() {
	int op;
	string entrar, inter, salir, pal;

	ListaEnlazada palabras;

	do
	{
		cout << "\n\t 1.INSERTAR INICIO 2. INSERTAR FINAL 3.INSERTAR INTER 4.MOSTRAR 5. SALIDA ";
		cin >> op;

		switch (op)
		{
		case 1:
			cout << "\t PALABRA: ";
			cin >> entrar;
			palabras.InsertarInicio(entrar);

			if (pal == "")
				cout << "\t SE HA INSERTADO: " << endl;
			else
				cout << "\n\t\ NO SE INSERTO" << endl;
			break;

		case 2:
			cout << "\t PALABRA: ";
			cin >> entrar;
			palabras.InsertarFinal(entrar);

			if (pal == "")
				cout << "\t SE HA INSERTADO: " << endl;
			else
				cout << "\n\t\ NO SE INSERTO" << endl;
			break;

		case 3:
			cout << "\t PALABRA: ";
			cin >> entrar;
			palabras.InsertarInter(entrar, entrar);

			if (pal == "")
				cout << "\t SE HA INSERTADO: " << endl;
			else
				cout << "\n\t\ NO SE INSERTO" << endl;
			break;


		case 4:
			palabras.Mostrar();
			break;
		default:
			cout << "Opcion invalida" << endl;
			break;
		}
	} while (op < 4);
}