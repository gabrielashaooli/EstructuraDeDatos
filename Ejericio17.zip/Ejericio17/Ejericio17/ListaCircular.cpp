#include "ListaCircular.h"


ListaCircular::ListaCircular() {
	cabecera = final = nodo = NULL;
}

ListaCircular::~ListaCircular() {}

void ListaCircular::Insertar(string nuevo) {
	nodo = new Palabra;
	nodo->pal = nuevo;

	if (cabecera == NULL) {
		cabecera = revisado = nodo;
	}
	else {
		final->sig = nodo;
	}
	nodo->sig = cabecera;
	final = nodo;
}

bool ListaCircular::Buscar(string Buscado) {
	nodo = cabecera;
	if (cabecera == NULL) {
		cout << "\n\tLista VAC�A. No encontrado" << endl;
		return false;
	}
	do {
		if (nodo->pal == Buscado) {
			revisado = nodo;
			return true;
		}
		nodo = nodo->sig;
	} while (nodo != revisado);

	return false;
}

void ListaCircular::Mostrar() {
	nodo = cabecera;
	cout << "\nLISTA DE PALABRAS: " << endl;

	if (cabecera == NULL) {
		cout << "\n\tLista Vac�a" << endl;
		return;
	}
	do {
		cout << "\t" << nodo->pal;
		if (nodo == cabecera)
			cout << "\t" << "<-- Cabecera";
		cout << endl;

		nodo = nodo->sig;

	} while (nodo != cabecera);
}

void ListaCircular::ExtraerIncio() {
}

void ListaCircular::ExtraerFinal() {
}

void ListaCircular::ExtraerInter() {
	{
		string  extraido;
		if (!cabecera)
		{
			cout << "\n\t**Lista VACIA. NO se extrae" << endl << endl;
			return;
		}

		revisado = NULL;

		nodo = cabecera;

		extraido = nodo->pal;

		if (revisado = cabecera);
		{



			delete nodo;
			return;
		}
	}
