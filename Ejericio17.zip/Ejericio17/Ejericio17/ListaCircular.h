#pragma once
#include <iostream>
#include <string>
using namespace std;

struct Palabra
{
	string pal;
	Palabra* sig;
};
class ListaCircular
{
public:
	ListaCircular();
	~ListaCircular();
	void Insertar(string);
	bool Buscar(string);
	void Mostrar();
	void ExtraerIncio();
	void ExtraerFinal();
	void ExtraerInter();

private: Palabra* cabecera, * final, * nodo, * revisado;

};

