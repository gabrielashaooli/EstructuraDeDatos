#include "ListaCircular.h"

void main() {
	setlocale(LC_ALL, "");

	string nuevo, buscado, extriado, siguiente;
	int opc;
	bool resultado;

	ListaCircular MiLista;

	do {
		cout << "\n Lista Circular de palabras " << endl;
		cout << "\t1. Insertar  2. Buscar  3. Mostrar  4. Extraer 5. Salir" << endl;
		cout << "\nEliga una opcion: "; cin >> opc;

		switch (opc)
		{
		case 1:
			cout << "Inserte un palabra: ";
			cin >> nuevo;
			MiLista.Insertar(nuevo);
			cout << "\tSe ha insertado la palabra correctamente" << endl;
			break;
		case 2:
			cout << "Inserte la palabra que le gustaria buscar: ";
			cin >> buscado;
			resultado = MiLista.Buscar(buscado);
			if (resultado)
				cout << "\n\t Se encontr� la palabra." << endl;
			else
				cout << "\n\t No se encontr� esa palabra." << endl;
			break;
		case 3:
			MiLista.Mostrar();
			break;

		case 4: 
			extraido = MiLista.Extraer();
			if (extraido != -1)
				cout << "\n\t se extrajo el entero inicio: " << extraido << endl << endl;
			break;

		default:
			break;
		}

	} while (opc < 5);


}