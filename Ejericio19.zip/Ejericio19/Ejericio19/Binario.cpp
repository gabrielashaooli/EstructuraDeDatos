#include "Binario.h"
#include "Binario.h"
Binario::Binario() {
	raiz = nodo = NULL;
}
void Binario::Crear(int nuevo) {
	nodo = new Num;
	nodo->numero = nuevo;
	nodo->izq = NULL;
	nodo->der = NULL;
}
Num* Binario::getRaiz() {
	return raiz;
}
void Binario::Insertar(Num* nuevo) {
	if (raiz == NULL) {
		raiz = nodo;
		cout << "Raiz creada." << endl;
		return;
	}
	if (nodo->numero < nuevo->numero) {
		if (nuevo->izq == NULL) {
			nuevo->izq = nodo;
			cout << "Se insert� a la izquierda de " << nuevo->numero << endl;
			return;
		}
		else {
			Insertar(nuevo->izq);
			return;
		}
	}
	if (nodo->numero > nuevo->numero) {
		if (nuevo->der == NULL) {
			nuevo->der = nodo;
			cout << "Se insert� a la derecha de " << nuevo->numero << endl;
			return;
		}
		else {
			Insertar(nuevo->der);
			return;
		}
	}
	cout << "Este n�mero ya existe, no se insert� nada." << endl;
}