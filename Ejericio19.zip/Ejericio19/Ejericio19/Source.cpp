#include "Binario.h"
enum Menu {
    Insertar = 1,
    RecorrerIn,
    RecorrerPre,
    RecorrerPos,
    Salir
};
void Menu() {
    cout << "\n\n Men�\n" << endl;
    cout << " 1) Insertar" << endl;
    cout << " 2)Salir" << endl;
}
int main()
{
    setlocale(LC_ALL, "");
    int entra;  int opcion;
    Num* inicio;
    Binario ABB;
    bool correrPrograma = true;
    while (correrPrograma) {
        Menu();
        cout << "\nDigita la opci�n que quieres realizar: ";
        cin >> opcion;
        switch (opcion) {
        case Insertar:
            cout << "\n�Qu� n�mero deseas insertar? ";
            cin >> entra;
            ABB.Crear(entra);
            inicio = ABB.getRaiz();
            ABB.Insertar(inicio);
            break;
        case Salir:
            correrPrograma = false;
            break;
        }
    }
}