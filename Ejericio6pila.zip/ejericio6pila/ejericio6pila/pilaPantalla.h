#pragma once
#include <string>
#define TAM 5
using namespace std;



class pilasPantalla
{
public:
	pilasPantalla();
	~pilasPantalla();
	string Insertar(string nuevo);
	string Extraer();
	void Mostrar();
	string Consultar();

private:
	int minimo, maximo, tope;
	string* pilaEnt;

};


