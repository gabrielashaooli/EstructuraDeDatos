#include "ListaEnlazada.h"

ListaEnlazada::ListaEnlazada()
{
	cabecera = final = nodo = NULL; 
}
ListaEnlazada :: ~ListaEnlazada() {

}

void ListaEnlazada::InsertarInicio(int nuevo) {
	nodo = new Enteros; 
	nodo->dato = nuevo;
	nodo->sig = cabecera;
	cabecera = nodo;
	if (final == NULL)
		final = nodo;
}

void ListaEnlazada::InsertarFinal(int nuevo) {
	if (!cabecera)
	{
			InsertarInicio(nuevo);
			return;
	}
	nodo = new Enteros;
	nodo->dato = nuevo;
	nodo->sig = NULL;
	final->sig = nodo;
	final = nodo;
}

void ListaEnlazada::InsertarOrden(int nuevo) {
	
	Enteros* nodoAnter, * nodoSiguiente;

	if (!cabecera)
	{
		InsertarInicio(nuevo);
		return;
	}

	nodoAnter = NULL;
	nodoAnter = cabecera;

	while (nodoSiguiente)
	{

		if (nodoSiguiente->dato > nuevo && nodoSiguiente == cabecera)
		{
			InsertarInicio(nuevo);
			return;
		}

		if (nodoSiguiente->dato > nuevo)

			nodo = new Enteros;
			nodo->dato = nuevo;
			nodo->sig = nodoAnter->sig;
			nodoAnter->sig = nodo;

			if (nodoAnter == final)
				final = nodo;
			return;

		}
		nodoAnter = nodoSiguiente;
		nodoSiguiente = nodoSiguiente->sig;
}

void ListaEnlazada::ExtraerIncio() {
	int extraido; 

	if (cabecera == NULL)
		return -1; 

	nodo = cabecera; 
	extraido = nodo->dato;
	cabecera = nodo->sig;
	delete nodo;

	return extraido;
}

void ListaEnlazada::mostrar(string lista) {

	cout << "\nLista de Enteros:" << endl; 
	if (cabecera)
	{
		cout << "t" << nodo->dato; 
		if (nodo == cabecera) cout << "\t>== Cabecera";
		if (nodo == final) cout << "\t>== Final";
		cout << endl;

		nodo = nodo->sig;
	}
}




	
