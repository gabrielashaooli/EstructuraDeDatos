#pragma once
#include <iostream>
using namespace std; 

struct Enteros
{
	Enteros* anterior;
	int num, dato;
	Enteros* sig;

};

class ListaEnlazada
{
public:
	ListaEnlazada();
	~ListaEnlazada();
	void InsertarOrden(int);
	void InsertarInicio(int);
	void InsertarFinal(int);
	void mostrar(string);
	void ExtraerIncio();

private:
	
	Enteros* cabecera, *final, *nodo, *anterior;

};

