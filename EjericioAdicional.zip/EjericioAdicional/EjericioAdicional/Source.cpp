#include "ListaEnlazada.h"

void main() {
	setlocale(LC_ALL, "");

	int opc, nuevonum;
	string anterior, extraido;
	string lista;

	ListaEnlazada Lista_a, Lista_b, Lista_c;

	do {
		cout << "\n Lista Circular Enlazada " << endl;
		cout << "\t1. Insertar  2. Mostrar  3. Combinar  4. Salir" << endl;
		cout << "\nEliga una opcion: "; cin >> opc;

		switch (opc)
		{
		case 1:
			cout << "Inserte un numero: ";
			cin >> nuevonum;

			cout << "\t�En que lista le gustaria insertarlo" << endl;
			cin >> lista;

			if (lista == "A")
				Lista_a.InsertarOrden(nuevonum);

			if (lista == "B")
				Lista_b.InsertarOrden(nuevonum);
			cout << "\n\t Se inserto el numero." << endl;

			break;

		case 2:
			Lista_a.mostrar("lISTA A");
			Lista_a.mostrar("lISTA B");
			Lista_a.mostrar("lISTA C");

			break;
		case 3:

			extraido = Lista_a.ExtraerIncio();
			if (extraido != -1)
				Lista_c.InsertarOrden(extraido);
		}
		while (extraido != -1);

		extraido = Lista_a.ExtraerIncio();
		if (extraido != -1)
			Lista_b.InsertarOrden(extraido);
	} while (extraido != -1);

	extraido = Lista_b.ExtraerIncio();
	if (extraido != -1)
		Lista_c.InsertarOrden(extraido);
}
while (extraido != -1);

		break;

		case 4:
		

		default:
			break;
		}

	} while (opc < 5);

