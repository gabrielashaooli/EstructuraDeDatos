#pragma once
class pilas
{
public:
	void insertar();
	void extraer();
	void 

};

