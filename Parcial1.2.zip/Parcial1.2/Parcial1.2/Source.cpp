#include "universidad.h"
using namespace std;

int main() {
	setlocale(LC_ALL, "");
	universidad CrearMenu;
	CrearMenu.Menu();
}

