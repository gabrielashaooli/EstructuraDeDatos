#include "universidad.h"

universidad::universidad()
{
};

void universidad::Registrar() {
    cout << "Ingrese el nombre de la universidad: ";
    cin >> nomuniversidad[numUnni].nUni;
    cout << "Ingrese el nombre del rector: ";
    cin >> nomuniversidad[numUnni].nRector;
    cout << "Ingrese la cantidad de alumnos: ";
    cin >> nomuniversidad[numUnni].cantalumno;

    cout << endl << "\tUniversidad agregada correctmente" << endl << endl;
    numUnni++;
    system("Pause");
};


void universidad::Mostrar() {
    cout << "MOSTRAR UNIVERSIDADES: " << endl;
    for (int i = 0; i < numUnni; i++) {
        cout << "\n\tNombre de la universidad: " << nomuniversidad[i].nUni << "\n\tNombre del rector: " << nomuniversidad[i].nRector << "\n\tNumero de alumnos: " << nomuniversidad[i].cantalumno << endl;
        cout << endl;
    }
    system("Pause");

void universidad::Menu() {
     do {
            system("cls");
            cout << "\t1. Registar Universidad\n\t2. Mostrar datos de la universidad \n\t3. Salir\n\t\tSeleccione la opci�n: ";
            cin >> opc;
            if (opc == 1) {
                system("cls");
                Registar();
            }
            else if (opc == 2) {
                system("cls");
                Mostar();
            }
            else if (opc == 3) {
                system("cls");
                cout << "Hasta luego" << endl;
            }
            else {
                cout << "Opci�n inv�lida" << endl;

            }
        } while (opc != 3);

}