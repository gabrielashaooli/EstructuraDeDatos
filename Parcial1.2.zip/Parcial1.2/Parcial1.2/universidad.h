#pragma once
#include<iostream>
#include <string>
using namespace std;


class universidad
{
    struct Uni
    {
        string nUni;
        string nRector;
        int cantalumno;

    }; 
	public:
		universidad();
		void Registrar();
		void Mostrar();
        void Menu();
        string nomb;
        int band = 0, opc = 0;
private:
    int numUnni = 0;
    Uni nomuniversidad [10];

};
