/*En la oficina de Caminos y puentes se necesita una aplicaci�n orientada a objetos en C++ 
que permita manejar la fila en la caseta de motocicletas. Para cada motocicleta se necesita conocer la marca y  el n�mero de cilindros.
Construye la aplicaci�n con la siguiente funcionalidad:

a.  Ingresar una motocicleta a la fila

b.  Pasar la siguiente motocicleta (extraer) para pagar, mostrando sus datos.

c.  Mostrar los datos de todas las motocicletas en la fila

Puedes elegir usar Cola Circular o Cola Ligada, la que prefieras*/

#include "cola.h"


void main()
{
	setlocale(LC_ALL, "");
	int opcion;
	Motocicleta entrada, salida;
	Cola Caseta;

	do
	{
		cout << "\n1 Insertar  2 Extraer  3 Mostrar  4 Salir: ";
		cin >> opcion;

		switch (opcion)
		{
		case 1:
			cout << "\n\t Ingrese la marca de la motocicleta: ";
			cin >> entrada.marca;
			cout << "\t Ingrese el numero de cilindros de la motocicleta: ";
			cin >> entrada.numcilindro;
			Caseta.Insertar(entrada);
			cout << "\t Se ha registrado la entrada de la motocicleta correctamente" << endl;
			break;

		case 2:
			salida = Caseta.Extraer();
			if (salida.marca == "")
				cout << "\n\t No hay motocicleta que extraer" << endl;
			else
				cout << "\n\t Motocicleta extraida: " << salida.marca << " " << salida.numcilindro << endl;
			break;

		case 3:
			Caseta.Mostrar();
			break;

		default:
			break;
		}

	} while (opcion < 4);
}

