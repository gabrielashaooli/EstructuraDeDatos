#include "cola.h"


Cola::Cola()
{
	inicio = final = nodo = NULL;
}
Motocicleta Cola::Extraer()
{
	Motocicleta extraido;

	if (inicio == NULL)
	{
		extraido.marca = "";
		extraido.numcilindro = "";
		return extraido;
	}

	nodo = inicio;
	extraido.marca = nodo->marca;
	extraido.numcilindro = nodo->numcilindro;
	inicio = nodo->sig;
	if (inicio == NULL)
		final = NULL;
	delete nodo;

	return extraido;
}
void Cola::Insertar(Motocicleta nuevo)
{
	nodo = new Motocicleta;
	nodo->marca = nuevo.marca;
	nodo->numcilindro = nuevo.numcilindro;
	nodo->sig = NULL;

	if (inicio == NULL)
		inicio = nodo;

	if (final != NULL)
		final->sig = nodo;

	final = nodo;
}
void Cola::Mostrar()
{
	cout << "\nMOTOCICLETA:" << endl;
	if (inicio == NULL)
	{
		cout << "\n\tCola VAC�A" << endl;
		return;
	}

	nodo = inicio;

	while (nodo != NULL)
	{
		cout << "\t" << nodo->marca << "\t" << nodo->numcilindro;
		if (nodo == inicio) cout << "\t<-- Inicio";
		if (nodo == final) cout << "\t<-- Final";
		cout << endl;

		nodo = nodo->sig;
	}
}
