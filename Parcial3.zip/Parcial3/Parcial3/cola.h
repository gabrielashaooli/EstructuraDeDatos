
#pragma once
#include <iostream>
#include <string>
		using namespace std;

	struct Motocicleta
	{
		string marca;
		string numcilindro;
		Motocicleta* sig;
	};


	class Cola
	{
	public:
		Cola();
		Motocicleta Extraer();
		void Insertar(Motocicleta);
		void Mostrar();
	private:
		Motocicleta* inicio, * final, * nodo;
	};
