﻿#include "ListaEnlazada.h"

ListaEnlazada::ListaEnlazada() {
	cabecera = ultimo = nodo = NULL;
}

void ListaEnlazada::Ordenar(int n) {
	numero* nodoAnter;
	if (!cabecera) {
		InsertarInicio(n);
		return;
	}
	nodo = cabecera;
	while (nodo != NULL) {
		if (nodo->num > n && nodo == cabecera) {
			InsertarInicio(n);
			return;
		}
		else if (nodo->sig == NULL) {
			InsertarFinal(n);
			return;
		}
		else if ((nodo->sig->num > n && nodo->num < n) || nodo->num == n) {
			InsertarIntermedio(n, nodo->num);
			return;
		}
		nodo = nodo->sig;
	}
}

void ListaEnlazada::Mostrar() {
	nodo = cabecera;
	while (nodo != NULL) {
		cout << nodo->num << " ";
		nodo = nodo->sig;
	}
	cout << endl;
}

void ListaEnlazada::InsertarInicio(int n) {
	nodo = new numero;
	nodo->num = n;
	nodo->sig = cabecera;
	cabecera = nodo;
	if (ultimo == NULL)
		ultimo = nodo;
}

void ListaEnlazada::InsertarFinal(int n) {
	if (!cabecera) {
		InsertarInicio(n);
		return;
	}
	nodo = new numero;
	nodo->num = n;
	nodo->sig = NULL;
	ultimo->sig = nodo;
	ultimo = nodo;
}

void ListaEnlazada::InsertarIntermedio(int nuevo, int anterior) {
	numero* nodoAnter;
	if (!cabecera) {
		cout << "\n*Lista VACIA, se insertara al inicio" << endl;
		InsertarInicio(nuevo);
		return;
	}
	nodoAnter = cabecera;
	cout << "Cabecera: " << cabecera->num << endl;
	while (nodoAnter != NULL) {
		if (nodoAnter->num == anterior) {
			nodo = new numero;
			nodo->num = nuevo;
			nodo->sig = nodoAnter->sig;
			nodoAnter->sig = nodo;
			return;
		}
		nodoAnter = nodoAnter->sig;
	}
	cout << "*No se encontro el taxi anterior " << anterior << " se insertara al final" << endl;
	InsertarFinal(nuevo);

}

int ListaEnlazada::Extraer() {
	int extraido;

	if (!cabecera) {
		return -1;
	}
	nodo = cabecera;
	extraido = nodo->num;
	cabecera = nodo->sig;
	delete nodo;
	return extraido;
}


