#pragma once
#include <iostream>
using namespace std; 

struct numero {
    int num;
    numero* sig;
};

class ListaEnlazada {
public:
    ListaEnlazada();
    void Ordenar(int);
    void InsertarInicio(int);
    void InsertarFinal(int);
    void InsertarIntermedio(int, int);
    void Mostrar();
    int Extraer();
 
private:
    numero* cabecera, * ultimo, * nodo;
};


