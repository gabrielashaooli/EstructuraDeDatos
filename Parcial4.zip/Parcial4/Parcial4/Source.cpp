#include "ListaEnlazada.h"

int main() {
    int opc, num, anter, taxiA, taxiB, extraida;
    ListaEnlazada listaA;
    ListaEnlazada listaB;
    ListaEnlazada listaC;
    do {
        cout << "1. Insertar un taxi con numero PAR " << endl;
        cout << "2. Insertar un taxi con numero IMPAR  " << endl;
        cout << "3. Mostrar lista PAR" << endl;
        cout << "4. Mostrar lista IMPAR   " << endl;
        cout << "5. Combinar " << endl;
        cout << "6.Extraer taxi con numero par  " << endl;
        cout << "7.Extraer taxi con numero impar  " << endl;
        cout << "8. Salir" << endl;
        cout << "Eliga una opcion: ";
        cin >> opc;
        switch (opc) {

        case 1:
            cout << "Inserte el Numero de taxi: ";
            cin >> num;
            listaA.Ordenar(num);
            break;
        case 2:
            cout << "Inserte el Numero de taxi impar: ";
            cin >> num;
            listaB.Ordenar(num);
            break;
        case 3:
            listaA.Mostrar();
            break;
        case 4:
            listaB.Mostrar();
            break;

        case 5:
            do {
                taxiA = listaA.Extraer();
                taxiB = listaB.Extraer();
                if (taxiA != -1) {
                    listaC.Ordenar(taxiA);
                }
                if (taxiB != -1) {
                    listaC.Ordenar(taxiB);
                }
            } while (taxiA != -1 && taxiB != -1);
            listaC.Mostrar();
            break;

        case 6: 
            extraida = listaA.Extraer();
            if (extraida == -1)
                cout << "\tLa lista est� VAC�A. NO se extrajo nada" << endl;
            else
                cout << "\tSe extrajo el numero de taxi:  " << extraida << endl;
            break;

        case 7:
            extraida = listaB.Extraer();
            if (extraida == -1)
                cout << "\tLa lista est� VAC�A. NO se extrajo nada" << endl;
            else
                cout << "\tSe extrajo el numero de taxi:  " << extraida << endl;
            break;

        case 8:
            cout << "Gracias por su preferencia!" << endl;
            break;
        default:
            cout << "Opcion no valida" << endl;
            break;
        }
    } while (opc != 6);
}