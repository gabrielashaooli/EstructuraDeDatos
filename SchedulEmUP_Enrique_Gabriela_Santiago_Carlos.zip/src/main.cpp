#include <iostream>
#include "main_menu.h"

using namespace std;

int main()
{
	main_menu();
	return 0;
}
