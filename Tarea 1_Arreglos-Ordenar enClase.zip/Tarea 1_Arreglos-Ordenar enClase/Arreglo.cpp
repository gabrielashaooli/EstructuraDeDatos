#include "Arreglo.h"

Arreglo::Arreglo()
{}
Arreglo::~Arreglo()
{}
void Arreglo::OrdenarBurbuja()
{
	bool ordenado = false;	// false=desordenado  true=ordenado
	int aux, ite=0;

	while (!ordenado)
	{
		ordenado = true;
		for (int i = 0; i < cont - ite - 1; i++)
		{
			if (arreglo[i] > arreglo[i + 1])
			{
				aux = arreglo[i];
				arreglo[i] = arreglo[i + 1];
				arreglo[i + 1] = aux;

				ordenado = false;
			}
		}
		ite++;
	}
}
void Arreglo::OrdenarBurbujaString()
{
	bool ordenado = false;	// false=desordenado  true=ordenado
	int  ite=0;
	string aux;

	while (!ordenado)
	{
		ordenado = true;
		for (int i = 0; i < contString - ite - 1; i++)
		{
			if (arreString[i] > arreString[i + 1])
			{
				aux = arreString[i];
				arreString[i] = arreString[i + 1];
				arreString[i + 1] = aux;

				ordenado = false;
			}
		}
		ite++;
	}
}
void Arreglo::Mostrar()
{

	for (int i = 0; i < cont; i++)
	{
		cout << arreglo[i] << "\t";
	}
	cout << endl << endl;
}
void Arreglo::MostrarString()
{

	for (int i = 0; i < contString; i++)
	{
		cout << arreString[i] << "\t";
	}
	cout << endl << endl;
}