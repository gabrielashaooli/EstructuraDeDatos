#pragma once
#include <iostream>
#include <string>
#define TAM 10
using namespace std;

class Arreglo
{
public:
	Arreglo();
	~Arreglo();
	void OrdenarBurbuja();
	void OrdenarBurbujaString();
	void Mostrar();
	void MostrarString();
private:
	int arreglo[TAM]{5,2,8,3,4,7};
	string arreString[TAM]{ "libro","casa","torre","ana","pez" };
	int cont = 6;
	int contString = 5;
};

