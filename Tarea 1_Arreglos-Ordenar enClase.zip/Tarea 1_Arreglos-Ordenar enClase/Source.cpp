#include "Arreglo.h"

int main()
{
	Arreglo miLista;

	/* Primera parte: Enteros */
	cout << "\n\tPrimera parte ENTEROS:" << endl;
	cout << "Original:";
	miLista.Mostrar();
	cout << "Ordenado:";
	miLista.OrdenarBurbuja();
	miLista.Mostrar();

	/* Segunda parte: PALABRAS */
	cout << "\n\tSegunda parte PALABRAS:" << endl;
	cout << "Original:";
	miLista.MostrarString();
	cout << "Ordenado:";
	miLista.OrdenarBurbujaString();
	miLista.MostrarString();
}	