#include "ColaCircular.h"

ColaCircular::ColaCircular(int tam)
{
	setlocale(LC_ALL, "");
	min = 0;
	max = tam - 1;
	principio = fin = -1;
	compradores = new string[tam];
}

ColaCircular::~ColaCircular()
{}

int ColaCircular::Insertar(string nombre)
{
	// Paso 1
	if (principio == min && fin == max) /* Cola llena */
		return -1;
	if (fin + 1 == principio) /*  Cola llena (circular)  */
		return -1;
	// Paso 2
	fin++;
	if (principio == -1)   /* Solo en caso de la primera inserci�n  */
		principio = fin;
	if (fin > max)	/* Si final lleg� al m�ximo, regresa a insertar en m�nimo (circular) */
		fin = min;
	// Paso 3
	compradores[fin] = nombre;

	return 0;
}

string ColaCircular::Premiar()
{
	string extraido;

	for (int i = 1; i <= 5; i++)
	{
		// Paso 1
		if (principio == -1)	/* Cola Vac�a */
			return "";
		// Paso 2
		extraido = compradores[principio];
		compradores[principio] = "";
		// Paso 3
		if (principio == fin)		/* Si se extrae el �ltimo nodo */
			principio = fin = -1;
		else                     /* Si se extrae un nodo que no es el �ltimo */
			principio++;
		if (principio > max)  /* Si principio lleg� a m�ximo, regresa a m�nimo (circular) */
			principio = min;
	}

	return extraido;
}

void ColaCircular::Mostrar()
{
	cout << "\nCOLA DE COMPRADORES:" << endl;

	for (int i = 0; i <= max; i++)
	{
		cout << "\t" << compradores[i];
		if (i == min)
			cout << "\t<-- M�nimo";
		if (i == max)
			cout << "\t<-- M�ximo";
		if (i == principio)
			cout << "\t<-- Principio";
		if (i == fin)
			cout << "\t<-- Final";
		cout << endl;
	}
}
