#pragma once
#include <iostream>
#include <string>
using namespace std;

class ColaCircular
{
public:
	ColaCircular(int);
	~ColaCircular();
	int Insertar(string);
	string Premiar();
	void Mostrar();
private:
	int min, max, principio, fin;
	string* compradores;
};

