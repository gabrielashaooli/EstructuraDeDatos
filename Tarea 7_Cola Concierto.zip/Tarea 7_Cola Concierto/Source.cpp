#include "ColaCircular.h"

void main()
{
	setlocale(LC_ALL, "");
	int tamano, resultado, opc;
	string comprador, premiado;

	cout << "Cantidad m�xima de compradores: ";
	cin >> tamano;

	ColaCircular Concierto(tamano);

	do
	{
		cout << "\n1 Comprar boleto   2 Premiar   3 Mostrar   4 Salir: ";
		cin >> opc;

		switch (opc)
		{
		case 1:
			cout << "\tNombre del comprador: ";
			cin >> comprador;
			resultado = Concierto.Insertar(comprador);
			if (resultado == 0)
				cout << "\tOK. Se registr� comprador" << endl;
			else
				cout << "\t%ERROR, Cola llena. NO se registro el comprador" << endl;
			break;
		case 2:
			premiado = Concierto.Premiar();
			if (premiado == "")
				cout << "\t%FINAL, Cola VACIA, no hay m�s premiados" << endl;
			else
				cout << "\tComprador premiado: " << premiado << endl;
			break;
		case 3:
			Concierto.Mostrar();
			break;
		}
	} while (opc < 4);
}