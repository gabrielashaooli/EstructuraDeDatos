#include "ListaLigadaCircular.h"

ListaLigadaCircular::ListaLigadaCircular()
{
	setlocale(LC_ALL, "");
	Cabecera = Final = NULL;
	Revisado = Anterior = NULL;
	Nodo = NULL;
}

ListaLigadaCircular::~ListaLigadaCircular()
{}

void ListaLigadaCircular::InsertarNom(string nva)
{
	Nodo = new Nombre();
	Nodo->dato = nva;
	if (!Cabecera)
	{
		Cabecera = Nodo;
		Final = Nodo;
		Revisado = Nodo;
	}
	Nodo->siguiente = Cabecera;
	Final->siguiente = Nodo;
	Cabecera = Nodo;
	Revisado = Nodo;
}

void ListaLigadaCircular::Mostrar()
{

	if (!Cabecera)
	{
		cout << "\n\t *** Lista VAC�A ***" << endl;
		return;
	}
	Nodo = Cabecera;
	cout << "\nLISTA:" << endl;
	do
	{
		cout << "\t" << Nodo->dato;
		if (Nodo == Cabecera)
			cout << "\t<-- Cabecera";
		if (Nodo == Final)
			cout << "\t<-- Final";
		cout << endl;
		Nodo = Nodo->siguiente;
	} while (Nodo != Cabecera);

}

void ListaLigadaCircular::Informar() {
	Nodo* actual;
	int cantidad = 0;
	for (actual = Cabecera; actual = NULL; actual = actual->siguiene)
		cantidad++
		return cantidad;
}


string ListaLigadaCircular:: ExtraerNodo()
{
	string extraida = "";
	if (!Cabecera)
		return "";
	Nodo = Cabecera;
	extraida = Nodo->dato;
	if (Revisado == Cabecera)
		Revisado = Cabecera->siguiente;
	if (Final == Cabecera)
		Cabecera = Final = NULL;
	else
	{
		Cabecera = Nodo->siguiente;
		Final->siguiente = Nodo->siguiente;
	}

	delete Nodo;

	return extraida;
}