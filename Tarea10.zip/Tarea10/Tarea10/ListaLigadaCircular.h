#pragma once
#include <string>
#include <iostream>
using namespace std;

struct Nombre
{
	Nombre* actual;
	string dato;
	Nombre* siguiente;
};
class ListaLigadaCircular
{
public:
	ListaLigadaCircular();
	~ListaLigadaCircular();
	void InsertarNom(string);
	string ExtraerNodo();
	void Mostrar();
	void Informar();

private:
	Nombre* Cabecera, * Final, * Nodo, * Revisado, * Anterior;
};

