#include "ListaLigadaCircular.h"

void main()
{
	string palabraNva, despuesDe, extraida, aExtraer;
	int opc;
	bool resultado;

	setlocale(LC_ALL, "");
	ListaLigadaCircular miLista;

	do
	{
		cout << "\n1 Insertar nombre   2 Informar Nodos   3 Extraer   4 Mostrar 5 Salir" << endl;
		cin >> opc;

		switch (opc)
		{
		case 1:
			cout << "\n\t�Insertar un nombre?: ";
			cin >> palabraNva;
			miLista.InsertarNom(palabraNva);
			cout << "\tOK. Se insert� el nombre" << endl;
			break;

		case 2:

		case 3:
			extraida = miLista.ExtraerNodo();
			if (extraida == "")
				cout << "\tLa lista est� VAC�A. NO se extrajo nada" << endl;
			else
				cout << "\tSe extrajo el nombre " << extraida << endl;
			break;

		case 4:
			miLista.Mostrar();
			break;

		default:
			break;
		}
		} while (opc < 5);
	}