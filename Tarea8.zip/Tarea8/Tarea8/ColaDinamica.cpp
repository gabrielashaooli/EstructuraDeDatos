#include "ColaDinamica.h"

ColaDinamica::ColaDinamica()
{
	inicio = final = nodo = NULL;
}
Trailer ColaDinamica::Extraer()
{
	Trailer extraido;

	if (inicio == NULL) 
	{
		extraido.placa = "";
		extraido.producto = "";
		return extraido;
	}

	nodo = inicio;
	extraido.placa = nodo->placa;
	extraido.producto = nodo->producto;
	inicio = nodo->sig;
	if (inicio == NULL)	
		final = NULL;
	delete nodo;

	return extraido;
}
void ColaDinamica::Insertar(Trailer nuevo)
{
	nodo = new Trailer;
	nodo->placa = nuevo.placa;
	nodo->producto = nuevo.producto;
	nodo->sig = NULL;

	if (inicio == NULL)  
		inicio = nodo;

	if (final != NULL)
		final->sig = nodo;

	final = nodo;
}
void ColaDinamica::Mostrar()
{
	cout << "\nTRAILERS:" << endl;
	if (inicio == NULL)
	{
		cout << "\n\tCola VAC�A" << endl;
		return;
	}

	nodo = inicio;

	while (nodo != NULL)
	{
		cout << "\t" << nodo->placa << "\t" << nodo->producto;
		if (nodo == inicio) cout << "\t<-- Inicio";
		if (nodo == final) cout << "\t<-- Final";
		cout << endl;

		nodo = nodo->sig;
	}
}