#pragma once
#include <iostream>
#include <string>
using namespace std;

struct Trailer
{
	string placa;
	string producto;
	Trailer* sig;
};


class ColaDinamica
{
public:
	ColaDinamica();
	Trailer Extraer();
	void Insertar(Trailer);
	void Mostrar();
private:
	Trailer* inicio, * final, * nodo;
};


