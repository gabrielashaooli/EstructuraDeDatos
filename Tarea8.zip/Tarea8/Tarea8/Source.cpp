/*Empleando C++ construye una aplicaci�n que opera la llegada y descarga de trailers en la Central de Abastos,
mediante la implementaci�n din�mica del TDA Cola.
Para cada tr�iler se deben registrar sus placas y el producto que transporta.*/


#include "ColaDinamica.h"

void main()
{
	setlocale(LC_ALL, "");
	int opcion;
	Trailer entrada, salida;
	ColaDinamica CentralAbastos;

	do
	{
		cout << "\n1 Insertar  2 Extraer  3 Mostrar  4 Salir: ";
		cin >> opcion;

		switch (opcion)
		{
		case 1:
			cout << "\n\t Ingrese la placa del trailer: ";
			cin >> entrada.placa;
			cout << "\t Ingrese el producto que se transportara: ";
			cin >> entrada.producto;
			CentralAbastos.Insertar(entrada);
			cout << "\t Se ha registrado el trailer correctamente" << endl;
			break;

		case 2:
			salida = CentralAbastos.Extraer();
			if (salida.placa == "")
				cout << "\n\t No se encuentra trailer para descargar" << endl;
			else
				cout << "\n\t Trailer Descargado: " << salida.placa << " " << salida.producto << endl;
			break;

		case 3:
			CentralAbastos.Mostrar();
			break;

		default:
			break;
		}

	} while (opcion < 4);
}