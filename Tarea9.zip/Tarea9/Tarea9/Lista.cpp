#include "Lista.h"

Lista::Lista()
{
	setlocale(LC_ALL, "");
	cabecera = NULL;
	fin = NULL;
}
Lista::~Lista()
{}
void Lista::Mostrar()
{
	if (!cabecera)
	{
		cout << "\n\t No se encontro nada, lista vac�a \n" << endl;
		return;
	}
	nodo = cabecera;
	cout << "\n lista enlazada: " << endl;
	while (nodo)
	{
		cout << "\t" << nodo->num;
		if (nodo == cabecera)
			cout << "\t<== Cabecera";
		cout << endl;
		nodo = nodo->siguiente;
	}
	cout << "\n\t FIN de la Lista" << endl;
}

void Lista::InsertarOrden(int nuevo)
{
	bool encontrado = false;
	Enteros* anterior, * actual;

	nodo = new Enteros;
	nodo->num = nuevo;

	if (!cabecera)
	{
		nodo->siguiente = NULL;
		cabecera = nodo;
		fin = nodo;
		cout << "\t Se ha insertado " << nuevo << " al inicio " << endl;
		return;
	}
	anterior = NULL;
	actual = cabecera;
	while (actual)
	{
		if (nuevo < actual->num)
		{
			encontrado = true;
			break;
		}
		anterior = actual;
		actual = actual->siguiente;
	}
	if (!encontrado)
	{
		nodo->siguiente = NULL;
		fin->siguiente = nodo;
		fin = nodo;
		cout << "\tSe ha insertado " << nuevo << " al final " << endl;
		return;
	}
	if (!anterior)
	{
		nodo->siguiente = cabecera;
		cabecera = nodo;
		cout << "\tSe ha insertado " << nuevo << " al inicio " << endl;
	}
	else
	{
		nodo->siguiente = anterior->siguiente;
		anterior->siguiente = nodo;	
		cout << "\tSe ha insertado| " << nuevo << " despu�s de " << anterior->num << endl;
	}

	return;
}
int Lista::ExtraerFin()
{
	int extraido;
	Enteros* anterior;

	extraido = -1;

	if (!cabecera)
	{
		cout << "\n\t**Lista VACIA. NO se extrae" << endl << endl;
		return extraido;
	}

	anterior = NULL;
	nodo = cabecera;
	while (nodo->siguiente != NULL)	
	{
		anterior = nodo;
		nodo = nodo->siguiente;
	}
	extraido = nodo->num;

	if (!anterior)
	{
		cabecera = NULL;
	}
	else
	{
		anterior->siguiente = NULL;	
	}
	fin = anterior;	
	delete nodo;	

	return extraido;
}
int Lista::ExtraerIni()
{
	int extraido = -1;

	if (!cabecera)
	{
		cout << "\n\t**Lista VACIA. NO se extrae" << endl << endl;
		return extraido;
	}

	nodo = cabecera;
	extraido = nodo->num;	
	cabecera = nodo->siguiente;	
	delete nodo;
	return extraido;
}
int Lista::ExtraerInter(int numExtraer)
{
	int  extraido = -1;
	Enteros* anterior;
	bool bandera = false;


	if (!cabecera)
	{
		cout << "\n\t**Lista VACIA. NO se extrae" << endl << endl;
		return extraido;
	}

	anterior = NULL;
	nodo = cabecera;

	while (nodo != NULL)
	{
		if (nodo->num == numExtraer)	
		{
			bandera = true;
			break;
		}
		anterior = nodo;
		nodo = nodo->siguiente;
	}

	if (!bandera)	
	{
		cout << "\n**NO existe " << numExtraer << " en la lista. NO se extrajo" << endl;
		return extraido;
	}

	extraido = nodo->num;	

	if (!anterior)	
		cabecera = nodo->siguiente;
	else 
		anterior->siguiente = nodo->siguiente;

	if (nodo == fin)	
		fin = anterior;

	delete nodo;	
	return extraido;
}