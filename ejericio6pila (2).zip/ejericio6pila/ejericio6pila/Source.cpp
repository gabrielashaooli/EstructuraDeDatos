/*Realiza la implementacion, sobre un arreglo estatico del tama�o que tu decidas, 
de una pila de pantallas. Parac cada pantalla se registrara su modelo que inicia con una letra seguida de digitos*/
#include "pilaPantalla.h"
#include <iostream>

int main()
{
	setlocale(LC_ALL, "");
	int opcion, sale;
	string entra;
	pilasPantalla MiLista;

	do
	{
		cout << "\n 1.Insertar 2.Extraer 3.Mostrar 4.Consultar 5.Salir ";
		cin >> opcion;
		switch (opcion)
		{

		case 1:
			cout << "\t �Que entero te gustaria insertar?";
			cin >> entra;
			sale = MiLista.Insertar(entra);
			if (sale == -1)
				cout << "\n\tPila llena, no se puede insertar" << endl;
			else
				cout << "\n\tSe inserto correctamente" << endl;

			break;

		case 2:
			sale = MiLista.Extraer();
			if (sale != -1)
				cout << "\tSe extrajo el entero" << sale << endl;
			else
				cout << "\n\t Pila vacia nada que extrajer" << sale << endl;

			break;

		case 3:
			MiLista.Mostrar();
			break;

		case 4:
			sale = MiLista.Consultar();
			if (sale == -1)
				cout << "\n\tPila vacia" << endl;
			else
				cout << "\tValor proximo a salir: " << sale << endl;
			break;

		default:
			break;

		}

	} while (opcion < 5);
}