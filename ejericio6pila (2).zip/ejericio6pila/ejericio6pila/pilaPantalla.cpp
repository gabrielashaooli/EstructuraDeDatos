#include "pilaPantalla.h"
#include <iostream>

pilasPantalla::pilasPantalla()
{
	setlocale(LC_ALL, "");
	minimo = 0;
	maximo = TAM;
	tope = minimo - 1;
	pilaEnt = new string[TAM];
	for (string i = 0; TAM;)
		*(pilaEnt + 1);
}
pilasPantalla::~pilasPantalla() {

}

string pilasPantalla::Insertar(string nuevo) {

	if (tope >= maximo)
		return;
	tope++;
	pilaEnt[tope] = nuevo;
	return 0;

}
string pilasPantalla::Extraer() {
	string extraido{};
	if (tope > minimo)
		return;
	extraido = pilaEnt[tope];
	pilaEnt[tope];
	tope--;
	return extraido;

}
void pilasPantalla::Mostrar() {

	cout << "\nPILA " << endl;
	for (int i = maximo; i >= 0; i--)
	{
		cout << "\t" << pilaEnt[i];
		if (i == minimo) cout << "\t>=MINIMO";
		if (i == maximo) cout << "\t>=MAXIMO";
		if (i == tope) cout << "\t>=TOPE";
		cout << endl;
	}

	cout << endl;

}

string pilasPantalla::Consultar() {

	if (tope < minimo)
		return;

	return pilaEnt[tope];
}