#include "Sushi.h"
#include <iostream>
using namespace std;

void main()
{
	setlocale(LC_ALL, "");
	int cuantos;

	cout << "�Cu�ntos platillos le gustaria ordenar del restaurante RICO SUSHI?: ";
	cin >> cuantos;
	Sushi miLista(cuantos);
	int opc, resultado;
	string X = "";

do
{
	cout << "\n BIENVENIDO A RICO SUSHI ";
	cout << "\n1 Agregar  2 Extraer   3 Consultar   4 Mostrar   5 Salir: ";
	cin >> opc;
	switch (opc)
	{
	case 1:
		cout << "\t�Qu� platillo le gustaria insertar?: ";
		cin >> X;
		resultado = miLista.Agregar(X);
		if (resultado == 0)
			cout << "\t el platillo ha sido insertado con exito " << X << endl;
		break;
	case 2:
		X = miLista.Extraer();
		if (X != "")
			cout << "\tEl platillo ha sido extraido del carrito de compras " << X << endl;
		break;
	case 3:
		X = miLista.Consultar();
		if (X != "")
			cout << "\tEl valor en tope es: " << X << endl;
		break;
	case 4:
		miLista.Mostrar();
		break;
	default:
		break;
	}
} while (opc < 5);
	}
