#include "Sushi.h"
using namespace std;
#include <iostream>

Sushi::Sushi(int tam)
{
	tamano = tam;
	arreglo = new string[tamano];
	minimo = 0;
	maximo = tamano - 1;
	tope = -1;
	for (int i = 0; i < tamano; i++)
		*(arreglo + i) = "- -";
}
int Sushi::Agregar(string mod)
{
	if (tope == maximo)
	{
		cout << "\n\tCarrito de compras LLENO" << endl;
		return -1;
	}
	tope++;
	*(arreglo + tope) = mod;
	return 0;
}
string Sushi::Extraer()
{
	string extraido;

	if (tope < minimo)
	{
		cout << "\n\t Carrito de compras VACIA. Nada que extraer" << endl;
		return "";
	}
	extraido = *(arreglo + tope);
	*(arreglo + tope) = "- -";
	tope--;
	return extraido;
}
string Sushi::Consultar()
{
	if (tope < minimo)
	{
		cout << "\n\tCarrito de compras VACIO" << endl;
		return "";
	}

	return *(arreglo + tope);
}
void Sushi::Mostrar()
{
	cout << "\nCARRITO DE COMPRAS:" << endl;
	for (int i = tamano - 1; i >= 0; i--)
	{
		cout << "\t" << *(arreglo + i);
		if (i == minimo) cout << "\t<== minimo";
		if (i == maximo) cout << "\t<== maximo";
		if (i == tope) cout << "\t<== tope";
		cout << endl;
	}
	cout << endl;
}
