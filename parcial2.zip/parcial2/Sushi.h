#pragma once
#include <string>
using namespace std;

	struct Empleado
	{
		
		string nom;
		int* piezas;
	};

	class Sushi
	{
	public:
		Sushi(int);
		int Agregar(string);
		string Extraer();
		string Consultar();
		void Mostrar();
	private:
		string* arreglo;
		int minimo, maximo, tope;
		int tamano;
	};
