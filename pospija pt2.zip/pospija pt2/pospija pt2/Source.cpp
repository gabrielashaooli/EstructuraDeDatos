#include "pila.h"
using namespace std;
#include <iostream>
#include <string>

int main() {
	setlocale(LC_ALL, ""); 


	string infija;

	cout << "Ingrese la expresi�n infija:";
	getline(cin, infija);

		pila pila_a;

		string postfija;


	// Recorrer la expresi�n infija
		for (char i : infija)
		{

			//  Si el car�cter es una variable o un n�mero, concatenarlo a postfija
			if (i >= 'a' && i <= 'z' || i >= '0' && i <= '9')
			{
				postfija += i;
			}

			//Si el car�cter es un operador, de mayor precedencia que el del tope, se inserta
			else if (i == '+' || i == '-')
			{
				if (pila_a.Empty() || pila_a.topData() == '(')
				{
					pila_a.push(i);
				}
				else {
					while (!pila_a.Empty() && pila_a.topData() != '(')
					{
						postfija += pila_a.pop();
					}
					pila_a.push(i);
				}

			}
			else if (i == ' *' || i == ' /')
			{
				if (pila_a.Empty() || pila_a.topData() == '(' || pila_a.topData() == '+' || pila_a.topData() == '_')
				{
					pila_a.push(i);

				}
				else
				{
					while (!pila_a.Empty() && pila_a.topData() != '(' && pila_a.topData() != '+' &&
						pila_a.topData() != '-')
					{
						postfija += pila_a.pop();
					}
					pila_a.push(i);
				}
			}
			// Si el car�cter es un par�ntesis izquierdo, se inserta en la pila con precedencia 0
			else if (i == '(') {
				{
					pila_a.push(i);
				}
			}
			//Si el car�cter es un par�ntesis derecho, se sacan todos los operadores de la pila hasta encontrar un par�ntesis izquierdo
			else if (i == ')') {

				while (pila_a.topData() != '(')
				{
					postfija += pila_a.pop();
					pila_a.pop();
					// Al finalizar, se sacan todos los operadores de la pila y se insertan a postfija
					while (!pila_a.Empty())
						postfija += pila_a.pop();
				}
				// Imprimir la expresi�n postfija
				cout << "La expresi�n postfija es: " << postfija << endl;
				return 0;
				}
			}
		};