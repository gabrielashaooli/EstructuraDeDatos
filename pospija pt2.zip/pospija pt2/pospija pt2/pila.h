#pragma once
#include <iostream>
	using namespace std;

	class pila {
	public:
		pila();
		~pila();
		void push(int);
		int pop();
		bool Empty();
		int topData();

	private:
		struct Node {
			int data;
			Node* next;
		};
		Node *top;
	};

